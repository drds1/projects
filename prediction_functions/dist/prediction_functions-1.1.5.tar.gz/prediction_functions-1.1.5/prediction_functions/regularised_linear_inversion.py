#generate synthetic observation
t = np.arange(0,100)





y = 0.5*np.sin(2*np;pi/30., * t) + 2.0*t**0.5




